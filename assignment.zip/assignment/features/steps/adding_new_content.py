from behave import given, when, then
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import NoSuchElementException
import setup


# TODO pridat jeste posledni test z tohoto souboru, ale muset nahrat akce na Methods page



@given('I am logged in as a producent')
def step_impl(context):
  context.driver.get("http://localhost:8080/repo")
  #context.driver.set_window_size(2048, 937)
  setup.login(context)


@when('I add new Method filling in all required fields')
def step_impl(context):
  # open page for creating new Method
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-factories']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # fill in required fields
  context.driver.find_element(By.ID, "method").click()
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("Method1")
  context.driver.find_element(By.ID, "form-widgets-method_purpose").send_keys("Method1 - purpose")
  # fill in Description
  context.driver.switch_to.frame(0)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - description'}", element)
  context.driver.switch_to.default_content()
  # fill in Strengths
  context.driver.switch_to.frame(1)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - strengths'}", element)
  context.driver.switch_to.default_content()
  # fill in Limitations
  context.driver.switch_to.frame(2)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - limitations'}", element)
  context.driver.switch_to.default_content()

@when('I save it')
def step_impl(context):
  # save new Method
  context.driver.find_element(By.ID, "form-buttons-save").click()
  context.driver.find_element(By.CSS_SELECTOR, ".documentFirstHeading").click()

@when('I search for the new Method in the Search Site')
def step_impl(context):
  context.driver.find_element(By.XPATH, "//*[@id=\"searchGadget\"]").send_keys("Method1")

@then('I should see the new Method in search results')
def step_impl(context):
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Method1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # teardown
  setup.delete_method_page(context)
  setup.logout(context)


# TODO zkusit pouzit
# http://localhost:8080/repo/method/++add++method



"""
# Test number: 7
  Scenario Outline: Producent doesn't save new page
    Given I am logged in as a producent
    When I add new page 
    And I click 'Cancel'
    And I search for this page in the search site
    Then I shouldn't see the new page in search results
"""
@when('I click \'Cancel\'')
def step_impl(context):
  context.driver.find_element(By.ID, "form-buttons-cancel").click()
  context.driver.find_element(By.CSS_SELECTOR, ".documentFirstHeading").click()
  
@then('I shouldn\'t see the new page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Method1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.logout(context)

"""
Scenario: Producent adds page without filling all required fields
    Given I am logged in as a producent
    When I add new Method without filling all required fields
    And I try to save it
    Then I should't be able to save the page
"""
@when('I add new Method without filling in all required fields')
def step_impl(context):
  # open page for creating new Method
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-factories']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # fill in required fields
  context.driver.find_element(By.ID, "method").click()
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("Method1")
  context.driver.find_element(By.ID, "form-widgets-method_purpose").send_keys("Method1 - purpose")

@then('I should\'t be able to save the page')
def step_impl(context):
  # expect error
  try:
    context.driver.find_element(By.XPATH, "//*[@id=\"content-core\"]/dl")
  except:
    assert False
