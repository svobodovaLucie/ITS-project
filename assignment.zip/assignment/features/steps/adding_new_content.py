from behave import given, when, then
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import NoSuchElementException
import setup

@given('producent is logged in')
def step_impl(context):
  context.driver.get("http://localhost:8080/repo")
  setup.login(context)

@when('producent adds new Method filling in all required fields')
def step_impl(context):
  # open page for creating new Method
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Methods").click()
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-factories']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # fill in required fields
  context.driver.find_element(By.ID, "method").click()
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("Method1")
  context.driver.find_element(By.ID, "form-widgets-method_purpose").send_keys("Method1 - purpose")
  # fill in Description
  context.driver.switch_to.frame(0)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - description'}", element)
  context.driver.switch_to.default_content()
  # fill in Strengths
  context.driver.switch_to.frame(1)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - strengths'}", element)
  context.driver.switch_to.default_content()
  # fill in Limitations
  context.driver.switch_to.frame(2)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - limitations'}", element)
  context.driver.switch_to.default_content()

@when('producent saves it')
def step_impl(context):
  # save new Method
  context.driver.find_element(By.ID, "form-buttons-save").click()

@when('producent searches for this Method page in the search site')
def step_impl(context):
    context.driver.find_element(By.ID, "searchGadget").send_keys("Method1")
    
@then('producent should see the new Method in search results')
def step_impl(context):
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Method1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # teardown
  setup.delete_page(context)
  setup.logout(context)

####################################################################################################################
@when('producent adds new Tool filling in all required fields')
def step_impl(context):
  # open page for creating a tool
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Tools").click()
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-factories']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  context.driver.find_element(By.ID, "tool").click()
  context.driver.implicitly_wait(2)
  
  # fill in required fields
  context.driver.find_element(By.ID, "form-widgets-IDublinCore-title").send_keys("Tool1")
  context.driver.find_element(By.ID, "form-widgets-tool_purpose").send_keys("Tool1 - purpose")
  context.driver.switch_to.frame(0)
  context.driver.find_element(By.CSS_SELECTOR, "html").click()
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Tool1 - description'}", element)
  context.driver.switch_to.default_content()
  context.driver.switch_to.frame(1)
  context.driver.find_element(By.CSS_SELECTOR, "html").click()
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Tool1 - strengths'}", element)
  context.driver.switch_to.default_content()
  context.driver.switch_to.frame(2)
  context.driver.find_element(By.CSS_SELECTOR, "html").click()
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Tool1 - limitations'}", element)
  context.driver.switch_to.default_content()

@when('producent searches for this Tool page in the search site')
def step_impl(context):
    context.driver.find_element(By.ID, "searchGadget").send_keys("Tool1")
    
@then('producent should see the new Tool in search results')
def step_impl(context):
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Tool1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # teardown
  setup.delete_page(context)
  setup.logout(context)

@when('producent adds new Use Case filling in all required fields')
def step_impl(context):
  # open page for creating new Use Case
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-factories']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.ID, "use_case").click()
  context.driver.implicitly_wait(2)
    
  # fill in required fields
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("UseCase1")
  # fill in Description
  context.driver.switch_to.frame(0)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'UseCase1 - description'}", element)
  context.driver.switch_to.default_content()

@when('producent searches for this Use Case page in the search site')
def step_impl(context):
    context.driver.find_element(By.ID, "searchGadget").send_keys("UseCase1")
    
@then('producent should see the new Use Case in search results')
def step_impl(context):
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "UseCase1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # teardown
  setup.delete_page(context)
  setup.logout(context)

@when('producent adds new Requirement filling in all required fields')
def step_impl(context):
  # open page for creating new Requirement
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-factories\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.ID, "plone-contentmenu-more").click()
  context.driver.find_element(By.ID, "form-field-requirement").click()
  context.driver.find_element(By.NAME, "form.button.Add").click()
  # fill in required fields
  context.driver.find_element(By.ID, "form-widgets-IDublinCore-title").send_keys("Requirement1")
  
@when('producent searches for this Requirement page in the search site')
def step_impl(context):
    context.driver.find_element(By.ID, "searchGadget").send_keys("Requirement1")
    
@then('producent should see the new Requirement in search results')
def step_impl(context):
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Requirement1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # teardown
  setup.delete_page(context)
  setup.logout(context)

@when('producent adds new Test Case filling in all required fields')
def step_impl(context):
  # open page for creating new Test Case
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-factories\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.ID, "plone-contentmenu-more").click()
  context.driver.find_element(By.ID, "form-field-test_case").click()
  context.driver.find_element(By.NAME, "form.button.Add").click()
  # fill in required fields
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("TestCase1")
  context.driver.find_element(By.ID, "form-widgets-test_case_id").send_keys("UC1_TC1")
  
@when('producent searches for this Test Case page in the search site')
def step_impl(context):
    context.driver.find_element(By.ID, "searchGadget").send_keys("TestCase1")
    
@then('producent should see the new Test Case in search results')
def step_impl(context):
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "TestCase1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # teardown
  setup.delete_page(context)
  setup.logout(context)

@when('producent adds new Evaluation Scenario filling in all required fields')
def step_impl(context):
  # open page for creating new Evaluation Scenario
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-factories\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.ID, "plone-contentmenu-more").click()
  context.driver.find_element(By.ID, "form-field-evaluation_scenario").click()
  context.driver.find_element(By.NAME, "form.button.Add").click()
  # fill in required fields
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("EvaluationScenario1")
  context.driver.find_element(By.ID, "form-widgets-evaluation_secnario_id").send_keys("ES1")
  context.driver.find_element(By.ID, "form-widgets-evaluation_scenario_textual_description").send_keys("EvaluationScenario1 - description")

@when('producent searches for this Evaluation Scenario page in the search site')
def step_impl(context):
    context.driver.find_element(By.ID, "searchGadget").send_keys("EvaluationScenario1")
    
@then('producent should see the new Evaluation Scenario in search results')
def step_impl(context):
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "EvaluationScenario1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # teardown
  setup.delete_page(context)
  setup.logout(context)

####################################################################################################################

@when('producent clicks \'Cancel\'')
def step_impl(context):
  context.driver.find_element(By.ID, "form-buttons-cancel").click()
  context.driver.find_element(By.CSS_SELECTOR, ".documentFirstHeading").click()
  
@then('producent shouldn\'t see the page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Method1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.logout(context)

@when('producent adds new Method without filling in all required fields')
def step_impl(context):
  # open page for creating new Method
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Methods").click()
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-factories']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # fill in required fields
  context.driver.find_element(By.ID, "method").click()
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("Method1")
  context.driver.find_element(By.ID, "form-widgets-method_purpose").send_keys("Method1 - purpose")

@then('producent should\'t be able to save the page')
def step_impl(context):
  # expect error
  try:
    context.driver.find_element(By.XPATH, "//*[@id=\"content-core\"]/dl")
  except:
    assert False
  finally:
    # teardown
    setup.logout(context)
    
@then('producent should see the new Method in list of Methods')
def step_impl(context):
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Methods").click()
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Method1")
  except:
    assert False, "Method1 should be visible in the list of Methods"
  finally:
    # teardown
    setup.search_page(context, "Method1")
    setup.delete_page(context)
    setup.logout(context)
