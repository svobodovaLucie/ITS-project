from behave import given, when, then
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import NoSuchElementException
import setup
import time

@given('there is a Tool page created')
def step_impl(context):
  # create Tool1
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Tools").click()
  setup.create_tool_page(context)

@given('producent is on the Tools page')
def step_impl(context):
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Tools").click()

@when('producent clicks on a Tool page')
def step_impl(context):
  time.sleep(1)
  element = context.driver.find_element(By.LINK_TEXT, "Tool1")

@then('producent should be able to edit the page')
def step_impl(context):
  try:
    search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id=\"contentview-edit\"]/a/span[2]")))
    search_result.location_once_scrolled_into_view
    search_result.click()
  except:
    assert False
  finally:
    # teardown
    setup.search_page(context, "Tool1")
    setup.delete_page(context)
    setup.logout(context)

@given('there is a Requirement page created')
def step_impl(context):
  # create Requirement1 page
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_requirement_page(context)

@when('producent edits the content')
def step_impl(context):
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id=\"contentview-edit\"]/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  # edit the name
  context.driver.find_element(By.ID, "form-widgets-IDublinCore-title").clear()
  context.driver.find_element(By.ID, "form-widgets-IDublinCore-title").send_keys("Requirement0")
  context.driver.find_element(By.ID, "form-buttons-save").click()

@when('producent searches for the Requirement page')
def step_impl(context):
  # open the page
  context.driver.find_element(By.XPATH, "//*[@id=\"searchGadget\"]").send_keys("Requirement0")
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Requirement0")))
  search_result.location_once_scrolled_into_view
  search_result.click()

@then('producent should see the edited content')
def step_impl(context):
  try:
    element = context.driver.find_element(By.XPATH, "//article[@id='content']/header/h1")
    if element.text != "Requirement0":
      assert False
  except:
    assert False
  finally:
    # teardown
    setup.search_page(context, "Requirement0")
    setup.delete_page(context)
    setup.logout(context)

@given('a producent edited Use Case page')
def step_impl(context):
  # login
  setup.login(context)
  # create Use Case page
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_use_case_page(context)
  setup.set_page_public(context)
  # edit Use Case page
  context.driver.find_element(By.XPATH, "//*[@id=\"searchGadget\"]").send_keys("UseCase1")
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "UseCase1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id=\"contentview-edit\"]/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  # edit the Description
  context.driver.switch_to.frame(0)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'UseCase1 - new description'}", element)
  context.driver.switch_to.default_content()
  # save
  context.driver.find_element(By.ID, "form-buttons-save").click()
  # logout
  setup.logout(context)

@when('I search for Use Case page')
def step_impl(context):
  context.driver.find_element(By.XPATH, "//*[@id=\"searchGadget\"]").send_keys("UseCase1")
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "UseCase1")))
  search_result.location_once_scrolled_into_view
  search_result.click()

@when(u'I open the page in search results')
def step_impl(context):
  pass


@then(u'I should see the edited content')
def step_impl(context):
  try:
    element = context.driver.find_element(By.XPATH, "//*[@id=\"formfield-form-widgets-use_case_description\"]/p[1]")
    if element.text != "UseCase1 - new description":
      assert False, "Element.text = " + element.text
  except:
    assert False
  finally:
    # teardown
    setup.login(context)
    setup.search_page(context, "UseCase1")
    setup.delete_page(context)
    setup.logout(context)
