from behave import given, when, then
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import NoSuchElementException
import setup
import time

@given('there are Method and Tool pages created on the web site')
def step_impl(context):
  time.sleep(1)
  # create Method1
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Methods").click()
  setup.create_method_page(context)
  # create Tool1
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Tools").click()
  setup.create_tool_page(context)


@given('I am on page where I can edit the Method')
def step_impl(context):
  context.driver.find_element(By.XPATH, "//*[@id=\"searchGadget\"]").send_keys("Method1")
  
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Method1")))
  search_result.location_once_scrolled_into_view
  search_result.click()

  # go to Edit page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id=\"contentview-edit\"]/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()

@when('I add Tool to the Tools field in Relations section')
def step_impl(context):
  # click to Relations
  context.driver.find_element(By.ID, "autotoc-item-autotoc-2").click()
  # click on 'path  form root'
  context.driver.find_element(By.XPATH, "//*[@id=\"formfield-form-widgets-tools\"]/div[2]/div[1]/div[1]/a/span").click()
  # send keys to Tools
  context.driver.find_element(By.XPATH, "//*[@id=\"s2id_autogen12\"]").send_keys("Tool1")
  # get Tool1
  context.driver.find_element(By.XPATH, "//div[@id=\'select2-result-label-15\']/div/div/a/div/span").click()

@when('I save the changes')
def step_impl(context):
  context.driver.find_element(By.ID, "form-buttons-save").click()

@when('I open the page for Method')
def step_impl(context):
  pass


@then('I should see the Tool in Tools section')
def step_impl(context):
  try:
   context.driver.find_element(By.LINK_TEXT, "Tool1").click()
  except NoSuchElementException:
    assert False, "Tool is not present on the Method's page"
  finally:
    # teardown
    # delete Method1
    setup.search_method_page(context)
    setup.delete_method_page(context)
    time.sleep(1)
    # delete Tool1
    setup.search_tool_page(context)
    setup.delete_tool_page(context)
    time.sleep(1)
    # logout
    setup.logout(context)
    
