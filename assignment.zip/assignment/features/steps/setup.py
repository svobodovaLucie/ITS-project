from behave import given, when, then
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import NoSuchElementException



# Function creates Method page
def create_method_page(context):
  # open page for creating new Method
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-factories']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  # fill in required fields
  context.driver.find_element(By.ID, "method").click()
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("Method1")
  context.driver.find_element(By.ID, "form-widgets-method_purpose").send_keys("Method1 - purpose")
  # fill in Description
  context.driver.switch_to.frame(0)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - description'}", element)
  context.driver.switch_to.default_content()
  # fill in Strengths
  context.driver.switch_to.frame(1)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - strengths'}", element)
  context.driver.switch_to.default_content()
  # fill in Limitations
  context.driver.switch_to.frame(2)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - limitations'}", element)
  context.driver.switch_to.default_content()
  
  # save new Method
  context.driver.find_element(By.ID, "form-buttons-save").click()
  context.driver.find_element(By.CSS_SELECTOR, ".documentFirstHeading").click()
  
  
# Login
def login(context):
  context.driver.find_element(By.ID, "personaltools-login").click()
  context.driver.find_element(By.ID, "__ac_name").send_keys("itsadmin")
  context.driver.find_element(By.ID, "__ac_password").send_keys("itsadmin")
  context.driver.find_element(By.CSS_SELECTOR, ".pattern-modal-buttons > #buttons-login").click()

# Logout
def logout(context):
  context.driver.find_element(By.CSS_SELECTOR, "#portal-personaltools span:nth-child(2)").click()
  context.driver.find_element(By.ID, "personaltools-logout").click()
  
def set_method_page_public(context):
  context.driver.find_element(By.ID, "searchGadget").click()
  context.driver.find_element(By.ID, "searchGadget").send_keys("Method1")
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Method1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  #context.driver.find_element(By.LINK_TEXT, "Method1").click()
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-workflow']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  #context.driver.find_element(By.CSS_SELECTOR, ".label-state-private > span:nth-child(2)").click()
  context.driver.find_element(By.ID, "workflow-transition-publish").click()
  
def search_method_page(context):
  #context.driver.find_element(By.ID, "searchGadget").click()
  #context.driver.find_element(By.ID, "searchGadget").send_keys("Method1")
  context.driver.find_element(By.XPATH, "//*[@id=\"searchGadget\"]").send_keys("Method1")
  context.driver.implicitly_wait(5)
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Method1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
# Function deletes Method page
def delete_method_page(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("Method1")
  
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Method1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  context.driver.find_element(By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/ul/li[4]/a").click()
  context.driver.find_element(By.XPATH, "//body[@id=\'visual-portal-wrapper\']/div[2]/div/div/div/div/div[3]/div/input").click()
  
  
  #search_method_page(context)
  """
  context.driver.find_element(By.ID, "searchGadget").send_keys("Method1")
  search_result = WebDriverWait(context.driver, 30).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Method1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  context.driver.implicitly_wait(5)
  
  context.driver.find_element(By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/a/span[2]").click()
  context.driver.find_element(By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/ul/li[4]/a").click()
  context.driver.find_element(By.XPATH, "//body[@id=\'visual-portal-wrapper\']/div[2]/div/div/div/div/div[3]/div/input").click()
  """
  
  """
  self.driver.get("http://localhost:8080/repo/method1")
    self.driver.set_window_size(1068, 981)
    self.driver.find_element(By.CSS_SELECTOR, "#plone-contentmenu-actions .plone-toolbar-title").click()
    self.driver.find_element(By.ID, "plone-contentmenu-actions-delete").click()
    self.driver.find_element(By.CSS_SELECTOR, ".pattern-modal-buttons > #form-buttons-Delete").click()
    element = self.driver.find_element(By.CSS_SELECTOR, ".pattern-modal-buttons > #form-buttons-Delete")
    actions = ActionChains(self.driver)
    actions.move_to_element(element).perform()
    element = self.driver.find_element(By.CSS_SELECTOR, "body")
    actions = ActionChains(self.driver)
    actions.move_to_element(element, 0, 0).perform()
  """
