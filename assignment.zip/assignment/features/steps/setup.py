from behave import given, when, then
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import NoSuchElementException
import time

# Function creates Method page
def create_method_page(context):
  # open page for creating new Method
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-factories']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.ID, "method").click()
  context.driver.implicitly_wait(2)
    
  # fill in required fields
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("Method1")
  context.driver.find_element(By.ID, "form-widgets-method_purpose").send_keys("Method1 - purpose")
  # fill in Description
  context.driver.switch_to.frame(0)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - description'}", element)
  context.driver.switch_to.default_content()
  # fill in Strengths
  context.driver.switch_to.frame(1)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - strengths'}", element)
  context.driver.switch_to.default_content()
  # fill in Limitations
  context.driver.switch_to.frame(2)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Method1 - limitations'}", element)
  context.driver.switch_to.default_content()
  
  # save new Method
  context.driver.find_element(By.ID, "form-buttons-save").click()

def create_tool_page(context):

  # open page for creating a tool
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-factories']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  context.driver.find_element(By.ID, "tool").click()
  context.driver.implicitly_wait(2)
  
  # fill in required fields
  context.driver.find_element(By.ID, "form-widgets-IDublinCore-title").send_keys("Tool1")
  context.driver.find_element(By.ID, "form-widgets-tool_purpose").send_keys("Tool1 - purpose")
  context.driver.switch_to.frame(0)
  context.driver.find_element(By.CSS_SELECTOR, "html").click()
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Tool1 - description'}", element)
  context.driver.switch_to.default_content()
  context.driver.switch_to.frame(1)
  context.driver.find_element(By.CSS_SELECTOR, "html").click()
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Tool1 - strengths'}", element)
  context.driver.switch_to.default_content()
  context.driver.switch_to.frame(2)
  context.driver.find_element(By.CSS_SELECTOR, "html").click()
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'Tool1 - limitations'}", element)
  context.driver.switch_to.default_content()
  
  # save new tool
  context.driver.find_element(By.ID, "form-buttons-save").click()

# Login
def login(context):
  context.driver.find_element(By.ID, "personaltools-login").click()
  context.driver.find_element(By.ID, "__ac_name").send_keys("itsadmin")
  context.driver.find_element(By.ID, "__ac_password").send_keys("itsadmin")
  context.driver.find_element(By.CSS_SELECTOR, ".pattern-modal-buttons > #buttons-login").click()

# Logout
def logout(context):
  context.driver.find_element(By.CSS_SELECTOR, "#portal-personaltools span:nth-child(2)").click()
  context.driver.find_element(By.ID, "personaltools-logout").click()
  
# TODO check jestli se neco nerozbilo
def set_page_public(context):
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-workflow']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  context.driver.find_element(By.ID, "workflow-transition-publish").click()
  
# Function deletes Method page
# Musime byt prihlaseni jako admin a byt na strance dane metody - to by se dalo vyuzit protoze vsude je delete, takze by se to mohlo dat mozna pouzit i pro ostatni veci jako tools atd.
def delete_page(context):
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
  context.driver.find_element(By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/ul/li[4]/a").click()
  context.driver.find_element(By.XPATH, "//body[@id=\'visual-portal-wrapper\']/div[2]/div/div/div/div/div[3]/div/input").click()
  
  #####################################################################################
# Function creates Method page
def create_use_case_page(context):
  # open page for creating new Use Case
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-factories']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.ID, "use_case").click()
  context.driver.implicitly_wait(2)
    
  # fill in required fields
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("UseCase1")
  # fill in Description
  context.driver.switch_to.frame(0)
  element = context.driver.find_element(By.ID, "tinymce")
  context.driver.execute_script("if(arguments[0].contentEditable === 'true') {arguments[0].innerText = 'UseCase1 - description'}", element)
  context.driver.switch_to.default_content()
 
  # save new Use Case
  context.driver.find_element(By.ID, "form-buttons-save").click()
  
# uplne stejne pro vsechny search?
def search_page(context, to_find):
  time.sleep(1)
  context.driver.find_element(By.XPATH, "//*[@id=\"searchGadget\"]").send_keys(to_find)
  
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, to_find)))
  search_result.location_once_scrolled_into_view
  search_result.click()
  
# Function creates Method page
def create_evaluation_scenario_page(context):
  # open page for creating new Evaluation Scenario
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-factories\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.ID, "plone-contentmenu-more").click()
  context.driver.find_element(By.ID, "form-field-evaluation_scenario").click()
  context.driver.find_element(By.NAME, "form.button.Add").click()
  # fill in required fields
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("EvaluationScenario1")
  context.driver.find_element(By.ID, "form-widgets-evaluation_secnario_id").send_keys("ES1")
  context.driver.find_element(By.ID, "form-widgets-evaluation_scenario_textual_description").send_keys("EvaluationScenario1 - description")
  
  # save new Evaluation Scenario
  context.driver.find_element(By.ID, "form-buttons-save").click()
  
def create_requirement_page(context):
  # open page for creating new Requirement
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-factories\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.ID, "plone-contentmenu-more").click()
  context.driver.find_element(By.ID, "form-field-requirement").click()
  context.driver.find_element(By.NAME, "form.button.Add").click()
  # fill in required fields
  context.driver.find_element(By.ID, "form-widgets-IDublinCore-title").send_keys("Requirement1")
  
  # save new Requirement
  context.driver.find_element(By.ID, "form-buttons-save").click()
  
def create_test_case_page(context):
  # open page for creating new Test Case
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-factories\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.ID, "plone-contentmenu-more").click()
  context.driver.find_element(By.ID, "form-field-test_case").click()
  context.driver.find_element(By.NAME, "form.button.Add").click()
  # fill in required fields
  context.driver.find_element(By.ID, "form-widgets-IBasic-title").send_keys("TestCase1")
  context.driver.find_element(By.ID, "form-widgets-test_case_id").send_keys("UC1_TC1")
  
  # save new Test Case
  context.driver.find_element(By.ID, "form-buttons-save").click()
