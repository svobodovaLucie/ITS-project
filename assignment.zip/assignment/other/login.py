from behave import *
from selenium.webdriver.common.by import By

@given(u'User is logged out')
def step_impl(context):
    #raise NotImplementedError(u'STEP: Given User is logged out')
    pass


@when(u'User logs in')
def step_impl(context):
    #raise NotImplementedError(u'STEP: When User logs in')
    context.driver.get("http://localhost:8080/repo")
    #self.driver.set_window_size(1024, 937)
    context.driver.find_element(By.ID, "personaltools-login").click()
    context.driver.find_element(By.ID, "__ac_name").click()
    context.driver.find_element(By.ID, "__ac_name").send_keys("itsadmin")
    context.driver.find_element(By.ID, "__ac_password").click()
    context.driver.find_element(By.ID, "__ac_password").send_keys("itsadmin")
    context.driver.find_element(By.CSS_SELECTOR, ".pattern-modal-buttons > #buttons-login").click()
  


@then(u'User can look at all content')
def step_impl(context):
    #raise NotImplementedError(u'STEP: Then User can look at all content')
    context.driver.get("http://localhost:8080/repo")
    #self.driver.set_window_size(1024, 937)
    context.driver.find_element(By.CSS_SELECTOR, "#contentview-folderContents span:nth-child(2)").click()
    
    # teardown
    context.driver.get("http://localhost:8080/repo")
    #self.driver.set_window_size(1024, 937)
    context.driver.find_element(By.CSS_SELECTOR, "#portal-personaltools span:nth-child(2)").click()
    context.driver.find_element(By.ID, "personaltools-logout").click()
  
