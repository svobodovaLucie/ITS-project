###############################################################
# File:        content_visibility.py                          #
# Project:     Testing and Dynamic Analysis (ITS) - project 2 #
# Author:      Lucie Svobodova, xsvobo1x                      #
# University:  FIT BUT, 2021/2022                             #
###############################################################

from behave import given, when, then
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import NoSuchElementException
import setup
import time

@given('I am not logged in')
def step_impl(context):
  context.driver.get("http://localhost:8080/repo")
    
@given('producent created a public Method page')
def step_impl(context):
  setup.login(context)
  # create Method1
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Methods").click()
  setup.create_method_page(context)
  setup.set_page_public(context)
  setup.logout(context)
  
@when('I search for this Method page in the search site')
def step_impl(context):
  context.driver.find_element(By.XPATH, "//*[@id=\"searchGadget\"]").send_keys("Method1")
    
@then('I should see the Method page in the search results')
def step_impl(context):
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Method1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  # teardown
  setup.login(context)
  setup.search_page(context, "Method1")
  setup.delete_page(context)
  setup.logout(context)
   
@given('producent created a private Method page')
def step_impl(context):
  # create private page as a producent
  setup.login(context)
  setup.create_method_page(context)
  setup.logout(context)
    
@then('I shouldn\'t see the Method page in the search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Method1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.login(context)
    setup.search_page(context, "Method1")
    setup.delete_page(context)
    setup.logout(context)
     
@given('there is a private Method page created')
def step_impl(context):
  setup.create_method_page(context)

@when('producent makes this Method page public')
def step_impl(context):
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-workflow']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.ID, "workflow-transition-publish").click()

@then('producent should see that the status of this Method page is public')
def step_impl(context):
  # find State element
  element = context.driver.find_element_by_xpath("//*[@id='plone-contentmenu-workflow']/a/span[2]/span[3]")
  if element.text == 'Published':
    pass
  else:
    assert False, "The status of the page is " + element.text
  
  # teardown
  setup.delete_page(context)
  setup.logout(context)

@given('there is a public Method page created')
def step_impl(context):
  setup.create_method_page(context)
  setup.set_page_public(context)

@when('producent makes this Method page private')
def step_impl(context):
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='plone-contentmenu-workflow']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.ID, "workflow-transition-reject").click()

@then('producent should see that the status of this Method page is private')
def step_impl(context):
  # find State element
  element = context.driver.find_element_by_xpath("//*[@id='plone-contentmenu-workflow']/a/span[2]/span[3]")
  if element.text == 'Private':
    pass
  else:
    assert False, "The status of the page is " + element.text
  
  # teardown
  setup.delete_page(context)
  setup.logout(context)

@when('I go on Methods page')
def step_impl(context):
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Methods").click()

@then('I should\'t see this page in the list of Methods')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Method1")
    assert False
  except AssertionError:
    assert False, "Method shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.login(context)
    setup.search_page(context, "Method1")
    setup.delete_page(context)
    setup.logout(context)
    
