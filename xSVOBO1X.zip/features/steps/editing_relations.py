###############################################################
# File:        editing_relations.py                           #
# Project:     Testing and Dynamic Analysis (ITS) - project 2 #
# Author:      Lucie Svobodova, xsvobo1x                      #
# University:  FIT BUT, 2021/2022                             #
###############################################################

from behave import given, when, then
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import NoSuchElementException
import setup
import time

@given('there are Method and Tool pages created')
def step_impl(context):
  time.sleep(1)
  # create Method1
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Methods").click()
  setup.create_method_page(context)
  # create Tool1
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Tools").click()
  setup.create_tool_page(context)

@given('I am on page where I can edit the Method')
def step_impl(context):
  context.driver.find_element(By.XPATH, "//*[@id=\"searchGadget\"]").send_keys("Method1")
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Method1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  # go to Edit page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id=\"contentview-edit\"]/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()

@when('I add Tool to the Tools field in Relations section')
def step_impl(context):
  # click to Relations
  context.driver.find_element(By.ID, "autotoc-item-autotoc-2").click()
  # click on 'path from root'
  context.driver.find_element(By.XPATH, "//*[@id=\"formfield-form-widgets-tools\"]/div[2]/div[1]/div[1]/a/span").click()
  # send keys to Tools
  context.driver.find_element(By.XPATH, "//*[@id=\"s2id_autogen12\"]").send_keys("Tool1")
  # get Tool1
  context.driver.find_element(By.XPATH, "//span[contains(.,'Tool1')]").click()

@when('I save the changes')
def step_impl(context):
  context.driver.find_element(By.ID, "form-buttons-save").click()

@when('I open the page for Method')
def step_impl(context):
  pass

@then('I should see the Tool in Tools section')
def step_impl(context):
  try:
   context.driver.find_element(By.LINK_TEXT, "Tool1").click()
  except NoSuchElementException:
    assert False, "Tool1 is not present on the Method1 page"
  finally:
    # teardown
    # delete Method1
    setup.search_page(context, "Method1")
    setup.delete_page(context)
    time.sleep(1)
    # delete Tool1
    setup.search_page(context, "Tool1")
    setup.delete_page(context)
    time.sleep(1)
    # logout
    setup.logout(context)
    
@given('producent created private TestCase1 page and public Requirement1 page')
def step_impl(context):
  # login
  setup.login(context)
  # create Requirement1 page
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_requirement_page(context)
  setup.set_page_public(context)
  # create TestCase1 page
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_test_case_page(context)
  
@given('Requirement1 has TestCase1 in Requirement Test Cases List')
def step_impl(context):
  # go to Requirement1 page
  setup.search_page(context, "Requirement1")
  context.driver.find_element(By.XPATH, "//li[@id=\'contentview-edit\']/a/span[2]").click()
  # click to Relations
  context.driver.find_element(By.XPATH, "//*[@id=\"autotoc-item-autotoc-1\"]").click()
  # click on 'path from root'
  context.driver.find_element(By.XPATH, "//*[@id=\'formfield-form-widgets-requirement_test_cases_list\']/div[2]/div/div/a/span").click()
  # send keys to Tools
  context.driver.find_element(By.XPATH, "//*[@id=\"s2id_autogen10\"]").send_keys("TestCase1")
  time.sleep(2)
  # get Tool1
  context.driver.find_element(By.XPATH, "//span[contains(.,'TestCase1')]").click()
  # save the relation
  context.driver.find_element(By.ID, "form-buttons-save").click()
  # logout
  setup.logout(context)

@when('I go to the Requirement1 page')
def step_impl(context):
  setup.search_page(context, "Requirement1")

@then('I should\'t see a TestCase1 in relations')
def step_impl(context):
  try:
    element = context.driver.find_element(By.LINK_TEXT, "TestCase1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.login(context)
    # delete Requirement1 page
    setup.search_page(context, "Requirement1")
    setup.delete_page(context)
    # delete TestCase1 page
    setup.search_page(context, "TestCase1")
    setup.delete_page(context)
    setup.logout(context)
    
@given('producent created a relation between public pages Use Case and Evaluation Scenario')
def step_impl(context):
  #return
  # login
  setup.login(context)
  # create UseCase1 page
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_use_case_page(context)
  setup.set_page_public(context)
  # create EvaluationScenario1 page
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_evaluation_scenario_page(context)
  setup.set_page_public(context)
  # add relation UseCase1-EvaluationScenario1
  setup.search_page(context, "UseCase1")
  context.driver.find_element(By.XPATH, "//li[@id=\'contentview-edit\']/a/span[2]").click()
  # click to Use Case Evaluation Scenarios
  context.driver.find_element(By.ID, "autotoc-item-autotoc-1").click()
  # click on 'path from root'
  context.driver.find_element(By.XPATH, "//div[@id=\'formfield-form-widgets-evaluation_scenario\']/div[2]/div/div/a/span").click()
  # send keys to Evaluation Scenarios
  context.driver.find_element(By.XPATH, "//*[@id=\"s2id_autogen2\"]").send_keys("EvaluationScenario1")
  time.sleep(2)
  # get EvaluationScenario1
  context.driver.find_element(By.XPATH, "//span[contains(.,'EvaluationScenario1')]").click()
  # save the relation
  context.driver.find_element(By.ID, "form-buttons-save").click()
  # logout
  setup.logout(context)

@when('I go on a Use Case page')
def step_impl(context):
  setup.search_page(context, "UseCase1")
  time.sleep(1)

@then('I should see a relation between Use Case and Evaluation Scenario')
def step_impl(context):
  # check if the relation is visible
  try:
   context.driver.find_element(By.LINK_TEXT, "EvaluationScenario1").click()
  except NoSuchElementException:
    assert False, "EvaluationScenario1 is not present on UseCase1 page"
  finally:
    # teardown
    # login
    setup.login(context)
    # delete UseCase1 page
    setup.search_page(context, "UseCase1")
    setup.delete_page(context)
    # delete EvaluationScenario1 page
    setup.search_page(context, "EvaluationScenario1")
    setup.delete_page(context)
    # logout
    setup.logout(context)
  
@given('there is relation between Method and Test Case')
def step_impl(context):
  time.sleep(1)
  # create Method1
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Methods").click()
  setup.create_method_page(context)
  # create TestCase1
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_test_case_page(context)
  # add relation Method1-TestCase1
  setup.search_page(context, "Method1")
  context.driver.find_element(By.XPATH, "//li[@id=\'contentview-edit\']/a/span[2]").click()
  # click to relations
  context.driver.find_element(By.ID, "autotoc-item-autotoc-2").click()
  # click on 'path from root'
  context.driver.find_element(By.XPATH, "//div[@id=\'formfield-form-widgets-test_case_or_verification_and_validation_activity\']/div[2]/div/div/a/span").click()
  # send keys to TestCase1
  context.driver.find_element(By.XPATH, "//*[@id=\"s2id_autogen8\"]").send_keys("TestCase1")
  time.sleep(2)
  # get TestCase11
  context.driver.find_element(By.XPATH, "//span[contains(.,'TestCase1')]").click()
  # save the relation
  context.driver.find_element(By.ID, "form-buttons-save").click()

@given('producent is on page where he can edit the Method')
def step_impl(context):
  setup.search_page(context, "Method1")
  context.driver.find_element(By.XPATH, "//li[@id=\'contentview-edit\']/a/span[2]").click()

@when('producent deletes the relation with Test Case')
def step_impl(context):
  context.driver.find_element(By.ID, "autotoc-item-autotoc-2").click()
  time.sleep(1)
  context.driver.find_element(By.XPATH, "//div[@id=\'formfield-form-widgets-test_case_or_verification_and_validation_activity\']/label").click()
  context.driver.find_element(By.XPATH, "//div[@id=\'s2id_autogen7\']/ul/li/a").click()
  context.driver.find_element(By.ID, "form-buttons-save").click()
  
@when('producent opens the page for Method')
def step_impl(context):
  setup.search_page(context, "Method1")

@then(u'producent shouldn\'t see the relation with Test Case')
def step_impl(context):
  try:
    context.driver.find_element(By.LINK_TEXT, "TestCase1")
    assert False
  except AssertionError:
    assert False, "TestCase1 shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    # delete Method page
    setup.search_page(context, "Method1")
    setup.delete_page(context)
    # delete Test Casepage
    setup.search_page(context, "TestCase1")
    setup.delete_page(context)
    # logout
    setup.logout(context)

@given('producent deleted a relation between Method and Test Case')
def step_impl(context):
  time.sleep(1)
  # login
  setup.login(context)
  # create Method1
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Methods").click()
  setup.create_method_page(context)
  setup.set_page_public(context)
  # create TestCase1
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_test_case_page(context)
  setup.set_page_public(context)
  # add relation Method1-TestCase1
  setup.search_page(context, "Method1")
  context.driver.find_element(By.XPATH, "//li[@id=\'contentview-edit\']/a/span[2]").click()
  # click to relations
  context.driver.find_element(By.ID, "autotoc-item-autotoc-2").click()
  # click on 'path from root'
  context.driver.find_element(By.XPATH, "//div[@id=\'formfield-form-widgets-test_case_or_verification_and_validation_activity\']/div[2]/div/div/a/span").click()
  # send keys to TestCase1
  context.driver.find_element(By.XPATH, "//*[@id=\"s2id_autogen8\"]").send_keys("TestCase1")
  time.sleep(2)
  # get TestCase11
  context.driver.find_element(By.XPATH, "//span[contains(.,'TestCase1')]").click()
  # save the relation
  context.driver.find_element(By.ID, "form-buttons-save").click()
  # delete the relation
  context.driver.find_element(By.XPATH, "//li[@id=\'contentview-edit\']/a/span[2]").click()
  context.driver.find_element(By.ID, "autotoc-item-autotoc-2").click()
  time.sleep(2)
  context.driver.find_element(By.XPATH, "//div[@id=\'formfield-form-widgets-test_case_or_verification_and_validation_activity\']/label").click()
  context.driver.find_element(By.XPATH, "//div[@id=\'s2id_autogen7\']/ul/li/a").click()
  context.driver.find_element(By.ID, "form-buttons-save").click()
  time.sleep(2)
  # logout
  setup.logout(context)

@when(u'I go on Method page')
def step_impl(context):
  setup.search_page(context, "Method1")

@then(u'I shouldn\'t see a relation between Method and Test Case')
def step_impl(context):
  try:
    context.driver.find_element(By.LINK_TEXT, "TestCase1")
    assert False
  except AssertionError:
    assert False, "TestCase1 shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.login(context)
    # delete Method page
    setup.search_page(context, "Method1")
    setup.delete_page(context)
    # delete Test Casepage
    setup.search_page(context, "TestCase1")
    setup.delete_page(context)
    # logout
    setup.logout(context)

