###############################################################
# File:        deleting_the_content.py                        #
# Project:     Testing and Dynamic Analysis (ITS) - project 2 #
# Author:      Lucie Svobodova, xsvobo1x                      #
# University:  FIT BUT, 2021/2022                             #
###############################################################

from behave import given, when, then
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import NoSuchElementException
import setup

@given('there is a Method page created')
def step_impl(context):
    setup.create_method_page(context)

@when('producent deletes this Method page')
def step_impl(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("Method1")
  # open Method page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Method1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  # delete the page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/ul/li[4]/a").click()
  context.driver.find_element(By.XPATH, "//body[@id=\'visual-portal-wrapper\']/div[2]/div/div/div/div/div[3]/div/input").click()

@when('producent deletes this Tool page')
def step_impl(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("Tool1")
  # open Tool page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Tool1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  # delete the page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/ul/li[4]/a").click()
  context.driver.find_element(By.XPATH, "//body[@id=\'visual-portal-wrapper\']/div[2]/div/div/div/div/div[3]/div/input").click()
  
@when('producent deletes this Use Case page')
def step_impl(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("UseCase1")
  # open Use Case page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "UseCase1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  # delete Use Case page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/ul/li[4]/a").click()
  context.driver.find_element(By.XPATH, "//body[@id=\'visual-portal-wrapper\']/div[2]/div/div/div/div/div[3]/div/input").click()

@when('producent deletes this Requirement page')
def step_impl(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("Requirement1")
  # open Requirement page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "Requirement1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  # delete the page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/ul/li[4]/a").click()
  context.driver.find_element(By.XPATH, "//body[@id=\'visual-portal-wrapper\']/div[2]/div/div/div/div/div[3]/div/input").click()
  
@when('producent deletes this Test Case page')
def step_impl(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("TestCase1")
  # open Test Case page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "TestCase1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  # delete the page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/ul/li[4]/a").click()
  context.driver.find_element(By.XPATH, "//body[@id=\'visual-portal-wrapper\']/div[2]/div/div/div/div/div[3]/div/input").click()
  
@when('producent deletes this Evaluation Scenario page')
def step_impl(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("EvaluationScenario1")
  # open Evaluation Scenario page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "EvaluationScenario1")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  # delete the page
  search_result = WebDriverWait(context.driver, 10).until(expected_conditions.element_to_be_clickable((By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/a/span[2]")))
  search_result.location_once_scrolled_into_view
  search_result.click()
  context.driver.find_element(By.XPATH, "//li[@id=\'plone-contentmenu-actions\']/ul/li[4]/a").click()
  context.driver.find_element(By.XPATH, "//body[@id=\'visual-portal-wrapper\']/div[2]/div/div/div/div/div[3]/div/input").click()
  
@given('producent deleted a Method page')
def step_impl(context):
  setup.login(context)
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Methods").click()
  setup.create_method_page(context)
  setup.set_page_public(context)
  setup.delete_page(context)
  setup.logout(context)
  
@given('producent deleted a Tool page')
def step_impl(context):
  setup.login(context)
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Tools").click()
  setup.create_tool_page(context)
  setup.set_page_public(context)
  setup.delete_page(context)
  setup.logout(context)

@given('producent deleted a Use Case page')
def step_impl(context):
  setup.login(context)
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_use_case_page(context)
  setup.set_page_public(context)
  setup.delete_page(context)
  setup.logout(context) 

@given('producent deleted a Requirement page')
def step_impl(context):
  setup.login(context)
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_requirement_page(context)
  setup.set_page_public(context)
  setup.delete_page(context)
  setup.logout(context)
  
@given('producent deleted a Test Case page')
def step_impl(context):
  setup.login(context)
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_test_case_page(context)
  setup.set_page_public(context)
  setup.delete_page(context)
  setup.logout(context)
  
@given('producent deleted a Evaluation Scenario page')
def step_impl(context):
  setup.login(context)
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_evaluation_scenario_page(context)
  setup.set_page_public(context)
  setup.delete_page(context)
  setup.logout(context)

@then('I shouldn\'t see the deleted page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Method1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
     
@then('producent shouldn\'t see the page in Tools page')
def step_impl(context):
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Tools").click()
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Tool1")
    assert False
  except AssertionError:
    assert False, "Tool1 shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.logout(context)

@given('a producent has deleted a Use Case page')
def step_impl(context):
  # login
  setup.login(context)
  # create Use Case page
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_use_case_page(context)
  # delete Use Case page
  setup.search_page(context, "UseCase1")
  setup.delete_page(context)
  # logout
  setup.logout(context)

@when('I open the Use Cases page')
def step_impl(context):
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()

@then('I shouldn\'t see the deleted page in Use Cases page')
def step_impl(context):
  try:
    element = context.driver.find_element(By.LINK_TEXT, "UseCase1")
    assert False
  except AssertionError:
    assert False, "UseCase1 shouldn't be visible"
  except NoSuchElementException:
    pass

@then('producent shouldn\'t see the deleted Method page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Method1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.logout(context)

@then('producent shouldn\'t see the deleted Tool page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Tool1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.logout(context)

@given('there is a Use Case page created')
def step_impl(context):
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_use_case_page(context)

@then('producent shouldn\'t see the deleted Use Case page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "UseCase1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.logout(context)

@then('producent shouldn\'t see the deleted Requirement page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Requirement1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.logout(context)

@given('there is a Test Case page created')
def step_impl(context):
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_test_case_page(context)
  setup.set_page_public(context)

@then('producent shouldn\'t see the deleted Test Case page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "TestCase1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.logout(context)

@given('there is a Evaluation Scenario page created')
def step_impl(context):
  context.driver.refresh()
  context.driver.find_element(By.LINK_TEXT, "Use Cases").click()
  setup.create_evaluation_scenario_page(context)
  setup.set_page_public(context)

@then('producent shouldn\'t see the deleted Evaluation Scenario page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "EvaluationScenario1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
  finally:
    # teardown
    setup.logout(context)

@then('I shouldn\'t see the deleted Method page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Method1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass

@when(u'I search for this Tool page in the search site')
def step_impl(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("Tool1")

@then('I shouldn\'t see the deleted Tool page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Tool1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass

@when('I search for this Use Case page in the search site')
def step_impl(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("UseCase1")

@then('I shouldn\'t see the deleted Use Case page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "UseCase1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass

@when('I search for this Requirement page in the search site')
def step_impl(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("Requirement1")

@then('I shouldn\'t see the deleted Requirement page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "Requirement1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass

@when('I search for this Test Case page in the search site')
def step_impl(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("TestCase1")

@then('I shouldn\'t see the deleted Test Case page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "TestCase1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass

@when('I search for this Evaluation Scenario page in the search site')
def step_impl(context):
  context.driver.find_element(By.ID, "searchGadget").send_keys("EvaluationScenario1")

@then('I shouldn\'t see the deleted Evaluation Scenario page in search results')
def step_impl(context):
  context.driver.implicitly_wait(2)
  try:
    element = context.driver.find_element(By.LINK_TEXT, "EvaluationScenario1")
    assert False
  except AssertionError:
    assert False, "Search result shouldn't be visible"
  except NoSuchElementException:
    pass
    
